import random
import fileinput
def writeTrueModel():
    model_clif = open('D:\colore-master\ontologies\data_v6\Model_Clif\lynx_data_sample2_case13_a1_true.clif', 'w')

    

    model = open('D:\colore-master\ontologies\data_v6\Case_13_SS_80\output\lynx_data_sample2_case13_a1.par.out', 'r')
    concepts = []
    for lines in model:
        if ('$true' in lines):
            lines = lines.lstrip('( ')
            lines = lines.lstrip('& ')
            lines = lines.split()
            lines = lines[0].replace(',',' ')
            lines = lines.split('(')
            lines = '('+lines[0]+' '+lines[1]
            print lines
            model_clif.write(lines)
            model_clif.write("\n")
            #f.write("\n")
    model.close()
    model_clif.close()

    i = 1
    domain = []
    while i < 41:
        y = '= "'+str(i)+'"'
        model = open('D:\colore-master\ontologies\data_v6\Case_13_SS_80\output\lynx_data_sample2_case13_a1.par.out', 'r')
        for lines in model:
            if (y in lines):
                x = lines.lstrip('& ')
                x = x.split()
                if len(x) == 4:
                    s = "'"+x[1] + "' " +x[3]
                    domain.append(s)
        i += 1
    print domain
    model.close()
    model_clif.close()

    

    # Replace the target string
    for t in domain:
        t = t.split()
        domainId = t[1]
        domainValue = t[0]
        fileName = 'D:\colore-master\ontologies\data_v6\Model_Clif\lynx_data_sample2_case13_a1_true.clif'
        inplace_change(fileName,domainId,domainValue)
            
def inplace_change(filename, old_string, new_string):
    # Safely read the input filename using 'with'
    print old_string
    with open(filename) as f:
        s = f.read()
        if old_string not in s:
            #print '"{old_string}" not found in {filename}.'.format(**locals())
            return

    # Safely write the changed content, if found in the file
    with open(filename, 'w') as f:
        print 'Changing "{old_string}" to "{new_string}" in {filename}'.format(**locals())
        s = s.replace(old_string, new_string)
        f.write(s)

