import random
import fileinput
def splitABox():
    d_case1 = open('D:\colore-master\ontologies\data_v6\SS_50_Case7\lynx_data_sample12_case7_a40.clif', 'w')

    #write the imports
    d_case1.write("(cl-text http://colore.oor.net/data_v6/SS_50_Case7/lynx_data_sample11_case7_a40.clif")
    d_case1.write("\n")
    
    #Case13 Imports
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/areal_region.clif)")
    d_case1.write("\n")
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/curve.clif)")
    d_case1.write("\n")
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/point.clif)")
    d_case1.write("\n")
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/point_region.clif)")
    d_case1.write("\n")
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/ep.clif)")
    d_case1.write("\n")
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/epp.clif)")
    d_case1.write("\n")
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/po.clif)")
    d_case1.write("\n")
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_cont/definitions/c.clif)")
    d_case1.write("\n")
    #d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/inc.clif)")
    #d_case1.write("\n")
    #d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/sc.clif)")
    #d_case1.write("\n")
    
    c = open('D:\colore-master\ontologies\data_v6\samples\selectedConcepts.txt', 'w')
    concepts = []
    with open('conceptAssertions_case13_ss80.txt') as f:
        lines = random.sample(f.readlines(),40)
        for x in lines:
            words = x.split("'")
            #write selected concept assertions to all the files
            d_case1.write(x)
            #write selected concepts to concepts file
            c.write(words[1])
            #create an array with selected concepts
            concepts.append(words[1])
            c.write("\n")
    c.close()
    print concepts
    
    with open('conceptRelations_PO.txt') as s:
        axioms = s.readlines()
        for y in axioms:
            t = []
            getConcepts = y.split("'")
            for word in getConcepts:
                if word.find('<')!= -1:
                    word = word.strip('<')
                    word = word.strip('>')
                    t.append(word)
            if set(t).issubset(set(concepts)):
                if y.startswith('(SC'):
                    d_case1.write("\n")
                    #replace SC with Cont and < axioms and write to 1,2,3,4,5,6,7,8,9,10 file
                    object1 = getConcepts[1].strip('<')
                    object2 = getConcepts[3].strip('<')
                    y = y.replace("<","")
                    d1 = "(and (exists (z)(and (Cont z '"+object1+"')(Cont z '"+object2+"')))(forall (z)(if(and(Cont z '"+object1+"')(Cont z '"+object2+"'))(and (< z '"+object1+"')(< z '"+object2+"')))))"
                    d_case1.write(d1)
                elif y.startswith('(Inc'):
                    d_case1.write("\n")
                    #replace SC with Cont and < axioms and write to 1,2,3,4,5,6,7,11,12 file
                    object1 = getConcepts[1].strip('<')
                    object2 = getConcepts[3].strip('<')
                    y = y.replace("<","")
                    d2 = "(or(exists (z)(and (< z '"+object1+"') (Cont z '"+object1+"') (P z '"+object2+"')))(exists (z)(and (< z '"+object2+"') (Cont z '"+object2+"') (P z '"+object1+"'))))"
                    d_case1.write(d2)
                elif y.startswith('(not (Inc'):
                    d_case1.write("\n")
                    #replace SC with Cont and < axioms and write to 1,2,3,4,5,6,7,11,12 file
                    object1 = getConcepts[1].strip('<')
                    object2 = getConcepts[3].strip('<')
                    y = y.replace("<","")
                    d21 = "(not (or(exists (z)(and (< z '"+object1+"') (Cont z '"+object1+"') (P z '"+object2+"')))(exists (z)(and (< z '"+object2+"') (Cont z '"+object2+"') (P z '"+object1+"')))))"
                    d_case1.write(d21)
                elif y.startswith('(PO'):
                    d_case1.write("\n")
                    #replace PO with P axioms and write to 2,4,9,12 file
                    #object1 = getConcepts[1].strip('<')
                    #object2 = getConcepts[3].strip('<')
                    y = y.replace("<","")
                    #d3 = "(exists (z)(and (P z '"+object1+"') (P z '"+object2+"')))"
                    d_case1.write(y)
                elif y.startswith('(not (PO'):
                    d_case1.write("\n")
                    #replace PO with P axioms and write to 2,4,9,12 file
                    #object1 = getConcepts[1].strip('<')
                    #object2 = getConcepts[3].strip('<')
                    y = y.replace("<","")
                    #d31 = "(not (exists (z)(and (P z '"+object1+"') (P z '"+object2+"'))))"
                    d_case1.write(y)
                elif y.startswith('(C'):
                    d_case1.write("\n")
                    #replace C with P axioms and write to 1,2,5,6,8,9,11,12 file
                    #object1 = getConcepts[1].strip('<')
                    #object2 = getConcepts[3].strip('<')
                    y = y.replace("<","")
                    d4 = "(exists (z)(and (Cont z '"+object1+"') (Cont z '"+object2+"')))"
                    d_case1.write(y)
                elif y.startswith('(not (C'):
                    d_case1.write("\n")
                    #replace C with P axioms and write to 1,2,5,6,8,9,11,12 file
                    #object1 = getConcepts[1].strip('<')
                    #object2 = getConcepts[3].strip('<')
                    y = y.replace("<","")
                    #d41 = "(not (exists (z)(and (Cont z '"+object1+"') (Cont z '"+object2+"'))))"
                    d_case1.write(y)
                elif y.startswith('(PP'):
                    d_case1.write("\n")
                    #replace C with P axioms and write to 1,2,5,6,8,9,11,12 file
                    #object1 = getConcepts[1].strip('<')
                    #object2 = getConcepts[3].strip('<')
                    y = y.replace("<","")
                    #d5 = "(and (P '"+object1+"' '"+object2+"') (not (= '"+object1+"' '"+object2+"')))"
                    d_case1.write(y)
                elif y.startswith('(P '):
                    y = y.replace("<","")
                    d_case1.write("\n")
                    d_case1.write(y)
            
    lines = open("D:\colore-master\ontologies\data_v6\samples\selectedConcepts.txt").readlines()
    items = lines
    m = [(items[i].strip('\n'),items[j].strip('\n')) for i in range(len(items)) for j in range(i+1, len(items))]
    print items
    for x in m:
        disjoint = "(not (= '"+ x[0] + "' '"+ x[1]+"'))"
        #write disjoint axioms to file
        d_case1.write(disjoint)
        d_case1.write("\n")

    d_case1.write(")")
    
    d_case1.close()
    print "Finished"
