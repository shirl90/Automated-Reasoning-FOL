import random
import fileinput
def getRandomConcepts(no, size):
    d_case1 = open('D:\colore-master\ontologies\data_v7\\restricted'+str(size)+'-'+str(no)+'_po.clif', 'w')
    d_case2 = open('D:\colore-master\ontologies\data_v7\\restricted'+str(size)+'-'+str(no)+'_ponew.clif', 'w')
    d_case3 = open('D:\colore-master\ontologies\data_v7\\restricted'+str(size)+'-'+str(no)+'_poc.clif', 'w')

    #write the imports
    d_case1.write("(cl-text http://colore.oor.net/data_v7/restricted'+str(size)+'-"+str(no)+"_po.clif")
    d_case1.write("\n")
    d_case2.write("(cl-text http://colore.oor.net/data_v7/restricted'+str(size)+'-"+str(no)+"_ponew.clif")
    d_case2.write("\n")
    d_case3.write("(cl-text http://colore.oor.net/data_v7/restricted'+str(size)+'-"+str(no)+"_poc.clif")
    d_case3.write("\n")

    #Case1 Imports
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/areal_region.clif)")
    d_case1.write("\n")
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/curve.clif)")
    d_case1.write("\n")
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/point.clif)")
    d_case1.write("\n")
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/point_region.clif)")
    d_case1.write("\n")
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/ep.clif)")
    d_case1.write("\n")
    d_case1.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/po.clif)")
    d_case1.write("\n")
    #Case2 Imports
    d_case2.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/areal_region.clif)")
    d_case2.write("\n")
    d_case2.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/curve.clif)")
    d_case2.write("\n")
    d_case2.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/point.clif)")
    d_case2.write("\n")
    d_case2.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/point_region.clif)")
    d_case2.write("\n")
    d_case2.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/ep.clif)")
    d_case2.write("\n")
    d_case2.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/ponew.clif)")
    d_case2.write("\n")
    #Case3 Imports
    d_case3.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/areal_region.clif)")
    d_case3.write("\n")
    d_case3.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/curve.clif)")
    d_case3.write("\n")
    d_case3.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/point.clif)")
    d_case3.write("\n")
    d_case3.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/point_region.clif)")
    d_case3.write("\n")
    d_case3.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/ep.clif)")
    d_case3.write("\n")
    d_case3.write("(cl-imports http://colore.oor.net/multidim_space_codi/definitions/poc.clif)")
    d_case3.write("\n")

    
    c = open('D:\colore-master\ontologies\data_v6\samples\selectedConcepts2.txt', 'w')
    concepts = []
    with open('D:\colore-master\ontologies\data_v6\samples\conceptAssertions.txt') as f:
        lines = random.sample(f.readlines(),size)
        for x in lines:
            words = x.split("'")
            #write selected concept assertions to all the files
            d_case1.write(x)
            d_case2.write(x)
            d_case3.write(x)
            #write selected concepts to concepts file
            c.write(words[1])
            #create an array with selected concepts
            concepts.append(words[1])
            c.write("\n")
    c.close()
    
    with open('D:\colore-master\ontologies\data_v6\samples\conceptRelations_PO_nonegPO.txt') as s:
        axioms = s.readlines()
        for y in axioms:
            t = []
            getConcepts = y.split("'")
            for word in getConcepts:
                if word.find('<')!= -1:
                    word = word.strip('<')
                    word = word.strip('>')
                    t.append(word)
            if set(t).issubset(set(concepts)):
                object1 = getConcepts[1].strip('<')
                object2 = getConcepts[3].strip('<')
                y = y.replace("<","")
                y = y.replace(">","")
                if y.startswith('(PO'):
                    print "FOUND PO fact: " + y 
                    #replace PO with P axioms
                    #write to each of the three cases in original form and replace
                    d_case1.write(y  + "\n")
                    d_case2.write(y  + "\n")
                    d_case3.write(y + "\n")
                    d = "(exists (z)(and (P z '"+object1+"') (P z '"+object2+"')))"
                elif y.startswith('(not (PO'):
                    #replace negated PO with P axioms
                    d = "(not (exists (z)(and (P z '"+object1+"') (P z '"+object2+"'))))"
                elif y.startswith('(SC'):
                    #replace SC with Cont and < axioms
                    d = "(and (exists (z)(and (Cont z '"+object1+"')(Cont z '"+object2+"')))(forall (z)(if(and(Cont z '"+object1+"')(Cont z '"+object2+"'))(and (< z '"+object1+"')(< z '"+object2+"')))))"
                elif y.startswith('(Inc'):
                    #replace SC with Cont and < axioms
                    d = "(or(exists (z)(and (< z '"+object1+"') (Cont z '"+object1+"') (P z '"+object2+"')))(exists (z)(and (< z '"+object2+"') (Cont z '"+object2+"') (P z '"+object1+"'))))"
                elif y.startswith('(not (Inc'):
                    #replace SC with Cont and < axioms
                    d = "(not (or(exists (z)(and (< z '"+object1+"') (Cont z '"+object1+"') (P z '"+object2+"')))(exists (z)(and (< z '"+object2+"') (Cont z '"+object2+"') (P z '"+object1+"')))))"
                elif y.startswith('(C'):
                    #replace C with Cont axioms
                    d = "(exists (z)(and (Cont z '"+object1+"') (Cont z '"+object2+"')))"
                elif y.startswith('(not (C'):
                    print "FOUND negated C fact: " + y 
                    #replace C with Cont axioms
                    #write to each of the three cases in original form (using PO) and replace
                    y = "(not (PO '"+object1+"' '"+object2+"'))"
                    d_case1.write(y + "\n")
                    d_case2.write(y + "\n")
                    d_case3.write(y + "\n")
                    d = "(not (exists (z)(and (Cont z '"+object1+"') (Cont z '"+object2+"'))))"
                elif y.startswith('(PP'):
                    #replace PP with P axioms
                    d = "(and (P '"+object1+"' '"+object2+"') (not (= '"+object1+"' '"+object2+"')))"
                elif y.startswith('(P '):
                    d = y
                d_case1.write(d + "\n")
                d_case2.write(d + "\n")
                d_case3.write(d + "\n")
            
    lines = open("D:\colore-master\ontologies\data_v6\samples\selectedConcepts2.txt").readlines()
    items = lines
    m = [(items[i].strip('\n'),items[j].strip('\n')) for i in range(len(items)) for j in range(i+1, len(items))]
    #print items
    for x in m:
        disjoint = "(not (= '"+ x[0] + "' '"+ x[1]+"'))"
        #write disjoint axioms to file
        d_case1.write(disjoint + "\n")
        d_case2.write(disjoint + "\n")
        d_case3.write(disjoint + "\n")

    d_case1.write(")")
    d_case2.write(")")
    d_case3.write(")")
    
    d_case1.close()
    d_case2.close()
    d_case3.close()
    print "Finished: size " + str(size) + ", sample " + str(no)

if __name__ == '__main__':
    import sys, os
    options = sys.argv
    s = int(options.pop())
    for i in range(13,17):
        getRandomConcepts(i, s)
        os.system('python tasks\check_consistency.py D:\\colore-master\\ontologies\data_v7\\restricted'+str(s)+"-"+str(i)+"_po.clif -simple")
        os.system('python tasks\check_consistency.py D:\\colore-master\\ontologies\data_v7\\restricted'+str(s)+"-"+str(i)+"_ponew.clif -simple")
        os.system('python tasks\check_consistency.py D:\\colore-master\\ontologies\data_v7\\restricted'+str(s)+"-"+str(i)+"_poc.clif -simple")
