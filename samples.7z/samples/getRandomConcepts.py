import random
import fileinput
def getRandomConcepts():
    p = open('D:\colore-master\ontologies\data_v6\Case_13_SS_80\lynx_data_sample2_case13.clif', 'w')
    po = open('D:\colore-testbed\ontologies\data_v5\Case_13_SS_80\lynx_data_sample40_PO.clif', 'w')
    c = open('D:\colore-master\ontologies\data_v6\samples\selectedConcepts.txt', 'w')
    concepts = []
    with open('conceptAssertions_lynx_data_sample2_case13.txt') as f:
        lines = random.sample(f.readlines(),70)
        for x in lines:
            words = x.split("'")
            #write selected concept assertions to P file
            p.write(x)
            #write selected concept assertions to PO file
            po.write(x)
            #write selected concepts to concepts file
            c.write(words[1])
            #create an array with selected concepts
            concepts.append(words[1])
            c.write("\n")
    c.close()
    
    with open('conceptRelations_PO.txt') as s:
        axioms = s.readlines()
        for y in axioms:
            t = []
            getConcepts = y.split("'")
            for word in getConcepts:
                if word.find('<')!= -1:
                    word = word.strip('<')
                    word = word.strip('>')
                    t.append(word)
            if set(t).issubset(set(concepts)):
                po.write(y)
                if y.startswith('(PO'):
                    #replace PO with P axioms and write to P file
                    d = '(exists (x)(and (and (Cont x "'+getConcepts[1]+'") (EqDim x "'+getConcepts[1]+'"))(and (Cont x "'+getConcepts[3]+'") (EqDim x "'+getConcepts[3]+'"))))'
                    p.write(d)
                    p.write("\n")
                elif y.startswith('(not (PO'):
                    #replace PO with P axioms and write to P file
                    d = '(not (exists (x)(and (and (Cont x "'+getConcepts[1]+'") (EqDim x "'+getConcepts[1]+'"))(and (Cont x "'+getConcepts[3]+'") (EqDim x "'+getConcepts[3]+'")))))'
                    #d = '(exists (x)(and (and (Cont x "'+getConcepts[1]+'") (EqDim x "'+getConcepts[1]+'"))(and (Cont x "'+getConcepts[3]+'") (EqDim x "'+getConcepts[3]+'"))))'
                    p.write(d)
                    p.write("\n")
                else:
                    #write remaining spatial axioms to P file
                    p.write(y)
        
    with open('conceptRelations_PO.txt') as s:
        axioms = s.readlines()
        for y in axioms:
            t = []
            getConcepts = y.split("'")
            for word in getConcepts:
                if word.find('<')!= -1:
                    word = word.strip('<')
                    word = word.strip('>')
                    t.append(word)
            #if set(t).issubset(set(concepts)):
                    #write selected spatial axioms to PO file
                    #po.write(y)

    lines = open("D:\colore-testbed\ontologies\data_v4\samples\selectedConcepts.txt").readlines()
    items = lines
    m = [(items[i].strip('\n'),items[j].strip('\n')) for i in range(len(items)) for j in range(i+1, len(items))]
    for x in m:
        disjoint = '(not (= "'+ x[0] + '" "'+ x[1]+'"))'
        #write disjoint axioms to file
        p.write(disjoint)
        po.write(disjoint)
        p.write("\n")
        po.write("\n")
    
    p.close()
    po.close()
    print "Finished"
