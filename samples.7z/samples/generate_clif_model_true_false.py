import random
import fileinput
def writeTrueFalseModel():
    model_clif = open('D:\colore-testbed\ontologies\data_v6\Partial_model\lynx_data_sample2_case7_true_false.clif', 'w')

    

    model = open('D:\colore-testbed\ontologies\data_v6\output\lynx_data_sample2_case7.par.out', 'r')
    concepts = []
    for lines in model:
        if ('$true' in lines):
            lines = lines.lstrip('( ')
            lines = lines.lstrip('& ')
            lines = lines.split()
            lines = lines[0].replace(',',' ')
            lines = lines.split('(')
            lines = '('+lines[0]+' '+lines[1]
            #print lines
            model_clif.write(lines)
            model_clif.write("\n")
        elif ('$false' in lines):
            lines = lines.lstrip('( ')
            lines = lines.lstrip('& ')
            lines = lines.split()
            lines = lines[0].replace(',',' ')
            lines = lines.split('(')
            lines = '(not ('+lines[0]+' '+lines[1]+')'
            #print lines
            model_clif.write(lines)
            model_clif.write("\n")
            #f.write("\n")
    model.close()
    model_clif.close()

    i = 1
    domain = []
    while i < 81:
        y = '= "'+str(i)+'"'
        print y
        model = open('D:\colore-testbed\ontologies\data_v6\output\lynx_data_sample2_case7.par.out', 'r')

        for lines in model:
            lines=lines.strip()
            if not lines.startswith("(![X]"):
                if (y in lines):
                    print lines
                    x = lines.lstrip('& ')
                    x = x.split()
                    b = '= "'+str(i)+'"'
                    #if x.endswith(b):
                    if len(x) == 4:
                        print x
                        s = "'"+x[1] + "' " +x[3]
                        domain.append(s)
        i += 1
    #print domain
    model.close()
    model_clif.close()

    

    # Replace the target string
    for t in domain:
        t = t.split()
        domainId = t[1]
        domainValue = t[0]
        fileName = 'D:\colore-testbed\ontologies\data_v6\Partial_model\lynx_data_sample2_case7_true_false.clif'
        #print domainId + domainValue
        inplace_change(fileName,domainId,domainValue)
    model_sample = open('D:\colore-testbed\ontologies\data_v6\Partial_model\lynx_data_sample2_case7_a20_true_false.clif', 'w')
    with open('D:\colore-testbed\ontologies\data_v6\Partial_model\lynx_data_sample2_case7_true_false.clif') as f:
        selected_lines = random.sample(f.readlines(),20)
        for w in selected_lines[:]:
            #print selected_lines
            model_sample.write(w)
            #model_sample.write("\n")
    model_sample.close()
            
def inplace_change(filename, old_string, new_string):
    # Safely read the input filename using 'with'
    #print old_string
    with open(filename) as f:
        s = f.read()
        if old_string not in s:
            #print '"{old_string}" not found in {filename}.'.format(**locals())
            return

    # Safely write the changed content, if found in the file
    with open(filename, 'w') as f:
        #print 'Changing "{old_string}" to "{new_string}" in {filename}'.format(**locals())
        s = s.replace(old_string, new_string)
        f.write(s)
